create procedure deleteStuBysnoWithProceedure(ss in number)
as
begin
    delete from student where sno=ss;
end;
/

