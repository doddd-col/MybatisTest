create procedure queryCountByGradeWithProcedure(gName in varchar, scount out number)
as
begin
    select count(1) into scount from student where graname=gname;
end
    /

